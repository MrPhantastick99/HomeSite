PHP Addition for Context Sensitive Help in HomeSite

Date :   May 3, 2002
From:    Richard Davies <RichardDavies@bigfoot.com>

Jeff,

Thanks for the PHP manual for Homesite. It's great but I was originally
looking for a way to use Homesite's context sensitive help with PHP
keywords. I found some of your posts on Macromedia's Homesite discussion
forums on this topic. I've created a file that can be added to the end
of the "Homesite 5\Help\htmlspec file list.idx" file which makes it
possible to use the context sensitive help with your PHP manual. All
that's required (assuming your manual has already been installed) is to
just cut-n-paste the contents of my file to the end of the previously
mentioned file and presto F1 works for PHP keywords! 

Please feel free to add a link to this file on your Php4Hs page so
others can use it. 

Also, no offense to the time and effort you've put into making this
great manual, but ideally, I'd prefer F1 to jump me right to the
documentation page on www.php.net. I haven't been able to come up with a
quick solution to this problem though because the idx file only seems to
work with local files and it doesn't work when I append "?name=value" to
a local file so I can't write a html file with a script to jump to the
respective page. Any ideas on a solution to this? 

+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=+
  Richard Davies
  RichardDavies@bigfoot.com
+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=+

