MySQL Tools Toolbar - ReadMe 1st

To Install the MySQL Tools toolbar, simply
copy the toolbar into your HomeSite X/userdata/toolbars/
folder.

Open HS and select "MySQL Tools" from the toolbar
context menu.

That's it!

Requirements:
A User "MUST" have the MySQL Tools Installed -
http://www.mysqltools.com/

Toolbar includes:
MySQL Booksonline
MySQL Explorer
MySQL Query
MySQL Service Manager
WinMySQL Admin

The tool bar assumes that MySQL Tools was installed
in it's default installation path (C:\Program Files\MySQL Tools\)
If the "icons" do not display, then thee links in the Toolbar are
not correct. Fear Not though, you can easily "fix" this...

Right Click on the "opened" MySQL Tools Toolbar, and
select the "customize" option...

Click on "MySQL Tools" from the "Visible Tools bars" list.

You should then see (red) boxes appear above.

Right-click on the box(es) and select the "edit" option.

From the newly opened dialog window, click the "browse" option
and point to the respective mysql tool... 

once a proper link is established..the "icon" will display.

repeat the process until all the tools are completed.

