------------------------------------------------------------
PHP 4 syntax coloring parser mod (for the HomeSite Editor)
------------------------------------------------------------

Version 4.6.3
By Sean Callan <sean.ch@gmail.com>
On 10/21/2004

This parser is a modification of the PHP 4 syntax coloring parser for
PHP that was released by Macromedia.  The modified source (.sc) is
included, as is a compiled .scc file (compiled with HomeSite 5.5). 

-----------------------
Changes:
-----------------------

- Updated recognized functions for PHP 4.3.

- Added recognition of variables and escape sequences ("\n", "\t", etc.)
  in strings.

-----------------------
Installation:
-----------------------

Instructions available here:

  http://www.wilk4.com/asp4hs/installation.htm#parser

-----------------------
Notes:
-----------------------

The list of recognized function names is not exactly comprehensive.
I generated it by starting with the functions listed on

  http://www.php.net/quickref.php 

and then removing anything that was listed as not in PHP 4 (e.g. only in
PHP 3 or PHP 5), only in a few versions of PHP (4.0.2-4.1.0 for example),
or marked as expiremental.  The current list contains 2323 functions.
More could probably be culled from the list but the parser is small/fast
enough for my purposes.

-----------------------
Source details:
-----------------------

php4b.sc is a modification of the php4.sc source from Macromedia.

-----------------------
For downloads of this file and any updates see:
-----------------------

  http://www.wilk4.com/asp4hs/
  http://www.wilk4.com/asp4hs/tsmdocs.htm

-----------------------
Revisions:
-----------------------

  10/21/2004  Sean Callan
  - Removed several dozen functions which aren't in PHP 4.
  - Disabled highlighting of HTML attributes because a bug in HomeSite
    causes errors when HTML attribute highlighting is enabled and more
    than one PHP block is included in a single HTML tag attribute.

  5/24/2004  Sean Callan
  - Added the recognition of "\t" in strings which was originally
    intended but was accidentally left out.

  5/21/2004  Sean Callan
  - Removed "com", "dir", and "variant" from the function list because
    they're classes, not functions.

  4/21/2004  Sean Callan
  - Initial version.
