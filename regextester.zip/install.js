/**
 * Regular Expression Tester install script.
 *
 * Attention: you need to run this script from within Homesite.
 * First make sure that sAppPath is set to the correct path (it's now set to
 * your Homesite directory + Script\RegExTester.
 *
 * @author Yuri Weseman <yoghoyogho@fastmail.fm>
 * @version install.js,v 1.0 2005/8/12
 */


var sAppPath = Application.AppPath + 'Scripts\\RegExTester\\';
var sToolBarName = "RegExTester";

function Main()
{
    var wsh = new ActiveXObject("WScript.Shell");
    var wshEnv = wsh.Environment('PROCESS');
    var systemRoot = wshEnv('SYSTEMROOT');
    
    objFSO = new ActiveXObject("Scripting.FileSystemObject");
    objFSO.CopyFile(sAppPath + 'RegExTools.dll', systemRoot + '\\RegExTools.dll');
    Application.ShellToAppAndWait('REGSVR32 ' + systemRoot + '\\RegExTools.dll');
    
    if (Application.ToolbarExists(sToolBarName) == 0) {
        Application.CreateToolbar (sToolBarName);
    }
    Application.ShowToolBar(sToolBarName);
    Application.AddScriptToolbutton(sToolBarName, sAppPath + 'regextester.js', 'Regular Expression Tester', 'RT', '');
    Application.AddScriptToolbutton(sToolBarName, sAppPath + 'uninstall.js', 'Uninstall Regular Expression Tester', 'UN', '');
}

function alert(msg)
{
    Application.Messagebox(msg, '', 0);
}