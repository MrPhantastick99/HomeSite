/*
* Regular Expression Tester for Homesite
* 
* Description: The regular expression tester will use the RegExTools DLL to show a form which will allow you to
* work on a regular expression for a given text.
* 
* Updates:
* 8/17/2000 - Highlighted text in active document is passed in as the source
*
* This script has been released to the public domain. If you make a change, please let me know, so I can add it,
* if necessary, to the original. You are free to distribute this script, as long as you leave this header in place.
*
* @author Corey Haines (corey@elender.hu)
*/
function Main() {
	var oRegExTester
	var sHighlight
	sHighlight = Application.ActiveDocument.SelText;
	oRegExTester = new ActiveXObject("RegExTools.clsRegExTester");
	oRegExTester.run("", sHighlight, "");
	oRegExTester = null;
}