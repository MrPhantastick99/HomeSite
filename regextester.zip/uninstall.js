/**
 * Uninstall script for Regular Expression Tester.
 *
 * Attention: you need to run this script from within Homesite.
 * First make sure that sAppPath is set to the correct path (it's now set to
 * your Homesite directory + Script\RegExTester.
 *
 * @author Yuri Weseman <yoghoyogho@fastmail.fm>
 * @version uninstall.js,v 1.0 2005/8/12
 */

var appPath = Application.AppPath + 'Scripts\\RegExTester\\';
var sToolBarName = "RegExTester";

function Main()
{
    var wsh = new ActiveXObject("WScript.Shell");
    var wshEnv = wsh.Environment('PROCESS');
    var systemRoot = wshEnv('SYSTEMROOT');
    
    Application.ShellToAppAndWait('REGSVR32 /U ' + systemRoot + '\\RegExTools.dll');
    
    Application.HideToolbar(sToolBarName)
    if (Application.ToolbarExists(sToolBarName) == 1) {
        Application.DeleteToolbar(sToolBarName);
    }
    
    try {
        var objFSO = new ActiveXObject("Scripting.FileSystemObject");
        objFSO.DeleteFile(systemRoot + '\\RegExTools.dll');
    } catch (e) {
    }
}

function alert(msg)
{
    Application.Messagebox(msg, '', 0);
}