********************************************************
Regular Expression Tester for Homesite v1.0 Aug. 12 2005
********************************************************

About the author

This regular expression was written by Corey Haines, and made
user-friendly by Yuri Weseman.

See also the notes below.

---------------------------------------------------------

Description of use

This archive contains a regular expression tester for Homesite. It will allow
you to test your regular expressions from within Homesite.

What is a regular expression? It's a mechanism by which you can define how 
to search for a specified sequence of characters in a data stream or file. 
Regular expressions are a powerful and flexible notation almost like a 
mini-programming language that allow you to describe text. In the context 
of pattern matching, regular expressions allow a succinct description of any 
arbitrary pattern. (taken from:
http://www.cisco.com/en/US/products/sw/secursw/ps2113/products_installation_and_configuration_guide_chapter09186a0080362cfd.html#wp503839)

After installation there will be a toolbar, called 'RegExTester' in your
toolbars menu. The will be two buttons:
- 'RT'
- 'UN'

About the 'RT' button

Using the 'RT' button, you can start the regular expression
tester. The regular expression tester will open a dialog, where you can fill in
several textfields. If you highlight a part of the current document before
clicking 'RT', that part will be used to fill in the 'source' textfield.
You can use the 'pattern' textfield to enter a regular expression.
Suppose the subject is:
yoghoyogho@fastmail.fm
And the pattern is:
^([a-z]*)@[a-z]*\.[a-z]*$
You will notice that the matches textfield will contain the entire e-mail adress.
The output textfield will be empty.
If you now enter $1 in the replace textfield, you will notice that the word before the
@ sign will be in the output field. This corresponds with the part of the pattern
that is between () (i.e.: ([a-z]*)). Should you've created the pattern like this:
^([a-z]*)@([a-z]*)\.([a-z]*)$
Then you could use $1, $2 and $3 in the replace textfield. $1 contains yoghoyogho,
$2 contains fastmail and $3 contains fm.

About the 'UN' button

You can use the 'UN' button should you want to uninstall the application. It will
unregister and delete the previously registered DLL, and remove the toolbar.

************
Installation
************

1. Extract this archive to your Homesite directory in a submap called 
   'Scripts\RegExTester' (or any other path, which you will have to 
   memorize now).

2. Go to this directory.

3. If you've extracted the archive to the directory I mentioned
above, go to step 5.

4. Open install.js and uninstall.js and change the sAppPath to 
the one were you extracted this archive.

5. Make sure Homesite is running. Open install.js in Homesite.

6. Hit control-shift-Q to run the install script.

That's it. Now you can use the regular expression tester from Homesite.
Should you want to uninstall the program, you can always use the
uninstall script that's included. In the newly created you will see
'UN', which will uninstall the Regular Expression Tester for you.

*****
Notes
*****

Author of regextester.js and RegExTools.dll: Corey Haines (corey@elender.hu)
Author of install.js, uninstall.js and readme.txt: Yuri Weseman (yoghoyogho@fastmail.fm)

http://www.weseman.net/regextester.zip

see also:
http://www.topxml.com/xslathome/
http://www.topxml.com/regextools/

**************
CHANGE HISTORY
**************

12/8/2005 v1.0

first release