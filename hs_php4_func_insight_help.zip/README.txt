------------------------------------------------------------
PHP 4 function insight and context sensitive help (for the HomeSite Editor)
------------------------------------------------------------

Version 1.1
By Sean Callan <sean.ch@gmail.com>
On 10/21/2004

This will enable function insight and context sensitive help for PHP 4
functions and make them available in the expression builder.  In order
for this to work you will also need to download the PHP manual.  Refer
to the installation section below for more information.

For those that don't know:
- Function insight displays a list of a function's parameters while
  you're typing the function.
- Context sensitive help displays a function's documentation if you
  hit the F1 key while the cursor is on the function's name.

-----------------------
IMPORTANT:
-----------------------

* If you install this as instructed the default ColdFusion function
  insight and expression builder elements will no longer be available.

* After installation the function insight section of the HomeSite options
  will take a very, VERY long time to display (about three minutes for me).

-----------------------
Installation:
-----------------------

** The location of your HomeSite directory depends on how you installed
   HomeSite, but by default it should be in "C:\Program Files\Macromedia".

1. Download the "many HTML files" version of the PHP manual which is
   available here:
   
     http://www.php.net/download-docs.php
   
   Extract the manual's files and put them in "HomeSite\Docs\PHPManual"
   (you will have to create the "PHPManual" directory in "HomeSite\Docs").

2. Put the new ExpressionElements.vtm file in "HomeSite\Extensions",
   replacing the existing file there (you should probably make a copy
   of the original file in case you ever want to switch back).

3. Open "HomeSite\Help\htmlspec file list.idx" in a text editor and
   copy/paste the contents of context_help.txt at the end of the file.

-----------------------
Notes:
-----------------------

After installing this as instructed the default ColdFusion function
insight and expression builder elements will no longer be available.
If you want to be able to restore the ColdFusion functionality you will
need to keep a copy of the original ExpressionElements.vtm file.  It may
also be possible to combine the original ColdFusion version with the new
PHP version, but I haven't tried and I think there could be problems
(some ColdFusion and PHP functions have the same name).

Another note is that the list of recognized functions is not exactly
comprehensive.  I generated it by starting with the functions listed on

  http://www.php.net/quickref.php 

and then removing anything that was listed as not in PHP 4 (e.g. only in
PHP 3 or PHP 5), only in a few versions of PHP (4.0.2-4.1.0 for example),
or marked as expiremental.  The current list contains 2323 functions.

-----------------------
Source details:
-----------------------

For the most part this was created by extracting the appropriate information
from the XML source files for the PHP manual.  For more information see:

  http://www.php.net/manual/howto/

-----------------------
For downloads of this file and any updates see:
-----------------------

  http://www.wilk4.com/asp4hs/php4hs.htm

-----------------------
Revisions:
-----------------------

  10/21/2004  Sean Callan
  - Removed several dozen functions which aren't in PHP 4.

  5/20/2004  Sean Callan
  - Created a new ExpressionElements.vtm file and context sensitive help
    links for PHP 4.3 functions.
