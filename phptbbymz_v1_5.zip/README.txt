-------------------------------------------------------------------------------------------------
PHP Toolbars version 1.0 - for HomeSite 5.0
      To help people code with PHP in HomeSite 5.0
 
-------------------------------------------------------------------------------------------------
To add these PHP Toolbars to HomeSite 5.0:

1. Unzip into a temp directory
2. Copy all VTM (.vtm) files to   C:\Program Files\Macromedia\HomeSite 5\Extensions\Tagdefs\PHP\
3. Copy all image (.bmp) files to   C:\Program Files\Macromedia\HomeSite 5\Extensions\Tagdefs\PHP\Images\
4. Copy all html (.html) files to   C:\Program Files\Macromedia\HomeSite 5\Extensions\Tagdefs\PHP\Docs\
5. Copy PHP & PHP DB (.tbr) to  C:\Program Files\Macromedia\HomeSite 5\Userdata\Toolbars\
6. Open HomeSite; right click on the Toolbar and select PHP and then PHP DB

You're all ready to go!!!!

-------------------------------------------------------------------------------------------------

IMPORTANT NOTE:
If you did not install HomeSite in the default directory then you'll 
have to edit the path for the button images and VTM files to match your directory structure.
If you need help on this, please e-mail:  php@zurnet.com

-------------------------------------------------------------------------------------------------

Release Notes:

8/31/2002 - V1.5
- Added Server Variables Button, Dialog and Help File
- Improved Setcookie Button by Adding Dialog and Help File
- Improved Help Files for MySQL and SendMail Dialogs
- Added PHP DB Toolbar
 - Modified MySQL Dialog
 - Added Query Button
 - Added Fetch Button
 - Added Close Button
 - Added Export to Flat File Button and Dialog
 - Added Import from Flat File Button and Dialog
 - Added Lock Button
- Minor Bug Fixes

-------------------------------------------------------------------------------------------------

8/11/2002 - V1.0
- PHP Toolbar for HomeSite v5.0

Known Issues...
-- Cannot Edit Assign, Array, Send Mail, and MySQL tags due to nature of PHP

-------------------------------------------------------------------------------------------------
Notes:
-PHP Toolbar is FREEWARE!!!
-This Toolbar was designed and created by Matt Zur - mattz@zurnet.com
-Check for updates here - http://zurnet.com/dl/hsphptb/index.shtml

Please send your comments and suggestions to php@zurnet.com
-------------------------------------------------------------------------------------------------

Matt Zur
mattz@zurnet.com
http://www.zurnet.com