PHP5 HomeSite syntax coloring parser

updated by "Jeremy Swinborne" <jeremy@techtrav.com>

added support for PHP5 for statements like  
  try, catch, throw, public, private, const, final etc...
 
and PHP objects like
  Exception, DomDocument, etc...

This is built the original Macromedia php4.sc as modified by Sean
Callan for his php4_b parser, that has PHP 4.3 functions.
 
the SCC was compiled in Homesite 5.2

available from http://www.wilk4.com/asp4hs/php4hs.htm#php5_parser_js

--
