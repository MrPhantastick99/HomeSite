TAG EDITOR TOOLBAR version 4.0 (for HS/CFS 4.0)

TagEditor Tool bar for making your own tageditors using Allaire's Visual Tools
Markup Language.
 

To add this Tag Editor Toolbar to HomeSite/Cold Fusion Studio 4.0:

************************************************************************
			I.M.P.O.R.T.A.N.T
	Toolbars written for HS/CFS 3.0 DO NOT WORK in HS/CFS 4.0
************************************************************************

Note: If your using Cold Fusion Studio 4.0 the substitute 'coldfusion studio4' 
for 'homesite4' in the following paths.

1. Unzip into a temp directory
2. Copy all VTM files to ..\Allaire\HomeSite4\Extensions\Tagdefs\Custom\
3. Copy all image files to ..\Allaire\HomeSite4\Extensions\Tagdefs\Custom\Images\
4. Copy Tag Editor.tbr  ..\Allaire\HomeSite4\Userdata\Toolbars\
5. Copy Tag Editor Template.html to ..\Allaire\HomeSite4\Wizards\Custom\
6. Open HomeSite/CFS and right click on the Toolbar and select the Tag Editor Toolbar.


Thats All Folks.

Important Note:
If you did not install HomeSite/Cold Fusion Studio in the default directory the you'll 
have to edit the path for the button images and VTM files to match your directory structor.

UPDATES:
11/01/98 Made New TagEditor toolbar for HS/CFS 4.0. get it from my site 
(http://www.citilink.com/~juggler)


Hint: I made a folder called Saved to keep a copy of all the custom made
VTM's in so they don't get replaced during the install/reinstall of the next HS/CFS
version.  

Later,

Wil Genovese (The Juggler)
Team Allaire
juggler@citilink.com
http://www.citilink.com/~juggler
