Instructions:

1. unzip the file to a local folder

2. place the file PHP.tbr into UserData\Toolbars under your Homesite5 folder.
   (i.e.: E:\Programmi\Macromedia\HomeSite 5\UserData\Toolbars)

3. place the images into Extension\Images under your Homesite5 folder. 
   (i.e.: E:\Programmi\Macromedia\HomeSite 5\Extensions\Images)

4. Open PHP.tbr with a text editor (or with Homesite: in this case you should 
   add .tbr extension in the option->settings->file settings tab).
   Change al the paths that refer the images according to your Homesite
   installation folder.

5. Right click near the other toolbars and select PHP from the dropdown menu.

6. You're done...
